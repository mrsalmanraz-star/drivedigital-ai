import React from 'react';
import { useQuery } from '@tanstack/react-query';

import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { MetricCard } from '../../components/dashboard/MetricCard';
import { RevenueChart } from '../../components/dashboard/RevenueChart';
import { UserGrowthChart } from '../../components/dashboard/UserGrowthChart';
import { ActivityFeed } from '../../components/dashboard/ActivityFeed';
import { QuickActions } from '../../components/dashboard/QuickActions';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { dashboardAPI } from '../../services/api/dashboard.api';

export const DashboardPage: React.FC = () => {
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ['dashboard-metrics'],
    queryFn: dashboardAPI.getMetrics,
  });

  const { data: revenueData, isLoading: revenueLoading } = useQuery({
    queryKey: ['dashboard-revenue'],
    queryFn: dashboardAPI.getRevenueData,
  });

  const { data: userGrowthData, isLoading: userGrowthLoading } = useQuery({
    queryKey: ['dashboard-user-growth'],
    queryFn: dashboardAPI.getUserGrowthData,
  });

  const { data: activities, isLoading: activitiesLoading } = useQuery({
    queryKey: ['dashboard-activities'],
    queryFn: dashboardAPI.getRecentActivities,
  });

  if (metricsLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-64">
          <LoadingSpinner size="lg" />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="mt-2 text-gray-600">
            Welcome back! Here's an overview of your digital ecosystem.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <QuickActions />
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Active Users"
            value={metrics?.activeUsers || 0}
            change={metrics?.activeUsersChange || 0}
            icon="users"
            color="blue"
          />
          <MetricCard
            title="Websites Built"
            value={metrics?.websitesBuilt || 0}
            change={metrics?.websitesBuiltChange || 0}
            icon="globe"
            color="green"
          />
          <MetricCard
            title="Apps Created"
            value={metrics?.appsCreated || 0}
            change={metrics?.appsCreatedChange || 0}
            icon="mobile"
            color="purple"
          />
          <MetricCard
            title="Monthly Revenue"
            value={metrics?.monthlyRevenue || 0}
            change={metrics?.monthlyRevenueChange || 0}
            icon="currency"
            color="indigo"
            isCurrency
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Overview</h3>
            {revenueLoading ? (
              <div className="flex items-center justify-center h-64">
                <LoadingSpinner size="md" />
              </div>
            ) : (
              <RevenueChart data={revenueData} />
            )}
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">User Growth</h3>
            {userGrowthLoading ? (
              <div className="flex items-center justify-center h-64">
                <LoadingSpinner size="md" />
              </div>
            ) : (
              <UserGrowthChart data={userGrowthData} />
            )}
          </div>
        </div>

        {/* Activity Feed */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
          </div>
          <div className="p-6">
            {activitiesLoading ? (
              <div className="flex items-center justify-center h-32">
                <LoadingSpinner size="md" />
              </div>
            ) : (
              <ActivityFeed activities={activities || []} />
            )}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};