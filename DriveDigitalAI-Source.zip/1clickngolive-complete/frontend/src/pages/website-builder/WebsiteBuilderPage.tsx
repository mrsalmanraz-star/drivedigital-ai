import React, { useState } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import { useMutation, useQuery } from '@tanstack/react-query';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

import { DashboardLayout } from '../../components/layout/DashboardLayout';
import { WebsiteBuilderCanvas } from '../../components/website-builder/WebsiteBuilderCanvas';
import { ComponentLibrary } from '../../components/website-builder/ComponentLibrary';
import { PropertiesPanel } from '../../components/website-builder/PropertiesPanel';
import { TemplateGallery } from '../../components/website-builder/TemplateGallery';
import { WebsiteBuilderToolbar } from '../../components/website-builder/WebsiteBuilderToolbar';
import { ProjectListView } from '../../components/website-builder/ProjectListView';
import { Button } from '../../components/ui/Button';
import { LoadingSpinner } from '../../components/ui/LoadingSpinner';
import { websiteBuilderAPI } from '../../services/api/website-builder.api';
import { useWebsiteBuilder } from '../../hooks/useWebsiteBuilder';

export const WebsiteBuilderPage: React.FC = () => {
  return (
    <DashboardLayout>
      <Routes>
        <Route index element={<ProjectListView />} />
        <Route path="new" element={<NewProjectView />} />
        <Route path="templates" element={<TemplateGalleryView />} />
        <Route path="editor/:projectId" element={<WebsiteEditorView />} />
      </Routes>
    </DashboardLayout>
  );
};

const ProjectListView: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('all');

  const { data: projects, isLoading } = useQuery({
    queryKey: ['website-projects'],
    queryFn: websiteBuilderAPI.getProjects,
  });

  const createProjectMutation = useMutation({
    mutationFn: websiteBuilderAPI.createProject,
    onSuccess: (project) => {
      navigate(`/website-builder/editor/${project.id}`);
    },
  });

  const handleCreateProject = async (templateId?: string) => {
    try {
      await createProjectMutation.mutateAsync({
        name: 'New Website Project',
        description: 'A new website project',
        templateId,
      });
    } catch (error) {
      console.error('Failed to create project:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="p-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Website Builder</h1>
          <p className="mt-2 text-gray-600">Create and manage your websites</p>
        </div>
        <div className="flex space-x-4">
          <Button
            variant="secondary"
            onClick={() => navigate('/website-builder/templates')}
          >
            Browse Templates
          </Button>
          <Button
            variant="primary"
            onClick={() => handleCreateProject()}
            disabled={createProjectMutation.isPending}
          >
            {createProjectMutation.isPending ? (
              <LoadingSpinner size="sm" className="mr-2" />
            ) : null}
            New Website
          </Button>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex items-center space-x-4 mb-6">
        <div className="flex-1 max-w-md">
          <input
            type="text"
            placeholder="Search projects..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="all">All Projects</option>
          <option value="published">Published</option>
          <option value="draft">Draft</option>
          <option value="archived">Archived</option>
        </select>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects?.map((project: any) => (
          <div
            key={project.id}
            className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => navigate(`/website-builder/editor/${project.id}`)}
          >
            {/* Project Preview */}
            <div className="h-40 bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center">
              <div className="text-6xl text-blue-200">🌐</div>
            </div>

            {/* Project Info */}
            <div className="p-4">
              <h3 className="text-lg font-semibold text-gray-900 mb-1">
                {project.name}
              </h3>
              <p className="text-sm text-gray-600 mb-2 line-clamp-2">
                {project.description || 'No description'}
              </p>
              <div className="flex items-center justify-between">
                <span className={`
                  inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                  ${project.status === 'published' 
                    ? 'bg-green-100 text-green-800' 
                    : project.status === 'draft'
                    ? 'bg-yellow-100 text-yellow-800'
                    : 'bg-gray-100 text-gray-800'
                  }
                `}>
                  {project.status}
                </span>
                <span className="text-xs text-gray-500">
                  {new Date(project.updatedAt).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {projects?.length === 0 && (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🎨</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No websites yet
          </h3>
          <p className="text-gray-600 mb-4">
            Get started by creating your first website or choosing from our templates.
          </p>
          <div className="flex items-center justify-center space-x-4">
            <Button
              variant="secondary"
              onClick={() => navigate('/website-builder/templates')}
            >
              Browse Templates
            </Button>
            <Button
              variant="primary"
              onClick={() => handleCreateProject()}
            >
              Create Website
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

const TemplateGalleryView: React.FC = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('all');

  const { data: templates, isLoading } = useQuery({
    queryKey: ['website-templates', selectedCategory],
    queryFn: () => websiteBuilderAPI.getTemplates(selectedCategory),
  });

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Website Templates</h1>
          <p className="mt-2 text-gray-600">Choose from our collection of professional templates</p>
        </div>
        <Button
          variant="secondary"
          onClick={() => navigate('/website-builder')}
        >
          Back to Projects
        </Button>
      </div>

      <TemplateGallery
        templates={templates || []}
        isLoading={isLoading}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        onTemplateSelect={(templateId) => {
          // Create project with template
          navigate('/website-builder/new', { state: { templateId } });
        }}
      />
    </div>
  );
};

const NewProjectView: React.FC = () => {
  const navigate = useNavigate();
  const { state } = location as any;
  const templateId = state?.templateId;

  // Auto-create project and redirect to editor
  React.useEffect(() => {
    if (templateId) {
      // Create project with template
      // This would be handled by the mutation
      navigate(`/website-builder/editor/new?template=${templateId}`);
    }
  }, [templateId, navigate]);

  return (
    <div className="flex items-center justify-center h-64">
      <LoadingSpinner size="lg" />
    </div>
  );
};

const WebsiteEditorView: React.FC = () => {
  const { projectId } = useParams<{ projectId: string }>();
  const {
    project,
    selectedComponent,
    components,
    isLoading,
    addComponent,
    updateComponent,
    selectComponent,
    saveProject,
    publishProject,
  } = useWebsiteBuilder(projectId!);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="flex h-screen bg-gray-50">
        {/* Component Library */}
        <div className="w-64 bg-white border-r border-gray-200">
          <ComponentLibrary onComponentAdd={addComponent} />
        </div>

        {/* Main Canvas Area */}
        <div className="flex-1 flex flex-col">
          {/* Toolbar */}
          <WebsiteBuilderToolbar
            project={project}
            onSave={saveProject}
            onPublish={publishProject}
          />

          {/* Canvas */}
          <div className="flex-1 overflow-auto">
            <WebsiteBuilderCanvas
              components={components}
              selectedComponent={selectedComponent}
              onComponentSelect={selectComponent}
              onComponentUpdate={updateComponent}
            />
          </div>
        </div>

        {/* Properties Panel */}
        <div className="w-80 bg-white border-l border-gray-200">
          <PropertiesPanel
            selectedComponent={selectedComponent}
            onComponentUpdate={updateComponent}
          />
        </div>
      </div>
    </DndProvider>
  );
};