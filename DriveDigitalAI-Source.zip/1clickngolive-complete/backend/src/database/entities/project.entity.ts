import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, OneToMany, JoinColumn } from 'typeorm';
import { ProjectType, ProjectStatus } from '../enums/project.enum';
import { Organization } from './organization.entity';
import { User } from './user.entity';
import { Template } from './template.entity';
import { ProjectVersion } from './project-version.entity';
import { ProjectBuild } from './project-build.entity';

@Entity('projects')
export class Project {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  organizationId: string;

  @Column()
  name: string;

  @Column({ type: 'text', nullable: true })
  description: string;

  @Column({
    type: 'enum',
    enum: ProjectType,
  })
  type: ProjectType;

  @Column({
    type: 'enum',
    enum: ProjectStatus,
    default: ProjectStatus.DRAFT,
  })
  status: ProjectStatus;

  @Column({ nullable: true })
  templateId: string;

  @Column({ type: 'jsonb', default: {} })
  configuration: Record<string, any>;

  @Column({ nullable: true })
  customDomain: string;

  @Column({ type: 'text', nullable: true })
  deploymentUrl: string;

  @Column({ type: 'jsonb', default: {} })
  seoSettings: Record<string, any>;

  @Column()
  createdById: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Relations
  @ManyToOne(() => Organization, organization => organization.projects)
  @JoinColumn({ name: 'organizationId' })
  organization: Organization;

  @ManyToOne(() => User, user => user.createdProjects)
  @JoinColumn({ name: 'createdById' })
  createdBy: User;

  @ManyToOne(() => Template, template => template.projects, { nullable: true })
  @JoinColumn({ name: 'templateId' })
  template: Template;

  @OneToMany(() => ProjectVersion, version => version.project, { cascade: true })
  versions: ProjectVersion[];

  @OneToMany(() => ProjectBuild, build => build.project, { cascade: true })
  builds: ProjectBuild[];
}