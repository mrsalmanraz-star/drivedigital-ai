import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, UpdateDateColumn, ManyToOne, OneToMany, JoinColumn } from 'typeorm';
import { User } from './user.entity';
import { OrganizationMember } from './organization-member.entity';
import { Project } from './project.entity';
import { Subscription } from './subscription.entity';

@Entity('organizations')
export class Organization {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  name: string;

  @Column({ unique: true })
  slug: string;

  @Column()
  ownerId: string;

  @Column({ default: 'starter' })
  subscriptionPlan: string;

  @Column({ default: 'active' })
  subscriptionStatus: string;

  @Column({ nullable: true })
  billingEmail: string;

  @Column({ nullable: true })
  customDomain: string;

  @Column({ type: 'jsonb', default: {} })
  brandingSettings: Record<string, any>;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  // Relations
  @ManyToOne(() => User, user => user.ownedOrganizations)
  @JoinColumn({ name: 'ownerId' })
  owner: User;

  @OneToMany(() => OrganizationMember, member => member.organization, { cascade: true })
  members: OrganizationMember[];

  @OneToMany(() => Project, project => project.organization)
  projects: Project[];

  @OneToMany(() => Subscription, subscription => subscription.organization)
  subscriptions: Subscription[];
}