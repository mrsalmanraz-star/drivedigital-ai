#!/bin/bash

# 1ClickNGolive Complete Setup Script
# This script sets up the entire development environment

set -e

echo "🚀 Setting up 1ClickNGolive Complete Platform..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    # Check if Docker is installed
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed. Please install Docker first."
        exit 1
    fi
    
    # Check if Docker Compose is installed
    if ! command -v docker-compose &> /dev/null; then
        print_error "Docker Compose is not installed. Please install Docker Compose first."
        exit 1
    fi
    
    # Check if Node.js is installed (for local development)
    if ! command -v node &> /dev/null; then
        print_warning "Node.js is not installed. Some local development features may not work."
    fi
    
    # Check if Git is installed
    if ! command -v git &> /dev/null; then
        print_warning "Git is not installed. Version control features may not work."
    fi
    
    print_success "Prerequisites check completed!"
}

# Create necessary directories
create_directories() {
    print_status "Creating necessary directories..."
    
    mkdir -p uploads
    mkdir -p build-artifacts
    mkdir -p logs
    mkdir -p ssl-certs
    mkdir -p database/backups
    
    print_success "Directories created successfully!"
}

# Generate environment files
generate_env_files() {
    print_status "Generating environment files..."
    
    # Backend .env
    cat > backend/.env << EOF
NODE_ENV=development
PORT=3001

# Database
DB_HOST=localhost
DB_PORT=5432
DB_USERNAME=postgres
DB_PASSWORD=postgres123
DB_NAME=1clickngolive

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# JWT
JWT_SECRET=$(openssl rand -base64 32)
JWT_EXPIRES_IN=24h

# AWS (Update with your credentials)
AWS_ACCESS_KEY_ID=your-aws-access-key-id
AWS_SECRET_ACCESS_KEY=your-aws-secret-access-key
AWS_REGION=us-east-1
AWS_S3_BUCKET=1clickngolive-storage

# Payment Gateways (Update with your keys)
STRIPE_SECRET_KEY=sk_test_your-stripe-secret-key
RAZORPAY_KEY_ID=your-razorpay-key-id
RAZORPAY_KEY_SECRET=your-razorpay-key-secret

# AI Services (Update with your key)
OPENAI_API_KEY=your-openai-api-key

# Email (Update with your SMTP settings)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password

# CORS
CORS_ORIGINS=http://localhost:3000,http://localhost:3001

# File Upload
MAX_FILE_SIZE=50MB
UPLOAD_PATH=./uploads

# Build Service
BUILD_TIMEOUT=300000
BUILD_CONCURRENCY=3
EOF

    # Frontend .env
    cat > frontend/.env << EOF
REACT_APP_API_URL=http://localhost:3001/api/v1
REACT_APP_WS_URL=ws://localhost:3001
REACT_APP_STRIPE_PUBLIC_KEY=pk_test_your-stripe-public-key
REACT_APP_GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
REACT_APP_VERSION=1.0.0
REACT_APP_ENVIRONMENT=development
EOF

    print_success "Environment files generated successfully!"
    print_warning "Please update the API keys and credentials in the .env files before starting the services."
}

# Setup database
setup_database() {
    print_status "Setting up database..."
    
    # Create database init script
    cat > database/init/01-init.sql << EOF
-- Create additional databases
CREATE DATABASE 1clickngolive_test;

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Create roles
CREATE ROLE app_user WITH LOGIN PASSWORD 'app_password';
GRANT CONNECT ON DATABASE 1clickngolive TO app_user;
GRANT USAGE ON SCHEMA public TO app_user;
GRANT CREATE ON SCHEMA public TO app_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO app_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO app_user;
EOF

    print_success "Database setup completed!"
}

# Install backend dependencies
setup_backend() {
    print_status "Setting up backend..."
    
    cd backend
    
    if command -v node &> /dev/null; then
        print_status "Installing backend dependencies..."
        npm install
        print_success "Backend dependencies installed!"
    else
        print_warning "Node.js not found. Skipping local dependency installation."
        print_warning "Dependencies will be installed when starting Docker containers."
    fi
    
    cd ..
}

# Install frontend dependencies
setup_frontend() {
    print_status "Setting up frontend..."
    
    cd frontend
    
    if command -v node &> /dev/null; then
        print_status "Installing frontend dependencies..."
        npm install
        print_success "Frontend dependencies installed!"
    else
        print_warning "Node.js not found. Skipping local dependency installation."
        print_warning "Dependencies will be installed when starting Docker containers."
    fi
    
    cd ..
}

# Setup monitoring
setup_monitoring() {
    print_status "Setting up monitoring..."
    
    mkdir -p infrastructure/monitoring
    
    # Prometheus config
    cat > infrastructure/monitoring/prometheus.yml << EOF
global:
  scrape_interval: 15s
  evaluation_interval: 15s

rule_files:
  # - "first_rules.yml"

scrape_configs:
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']

  - job_name: '1clickngolive-backend'
    static_configs:
      - targets: ['backend:3001']
    metrics_path: '/api/v1/metrics'

  - job_name: '1clickngolive-frontend'
    static_configs:
      - targets: ['frontend:3000']

  - job_name: 'redis'
    static_configs:
      - targets: ['redis:6379']

  - job_name: 'postgres'
    static_configs:
      - targets: ['postgres:5432']
EOF

    print_success "Monitoring setup completed!"
}

# Create startup script
create_startup_script() {
    print_status "Creating startup scripts..."
    
    # Development startup script
    cat > start-dev.sh << EOF
#!/bin/bash

echo "🚀 Starting 1ClickNGolive Development Environment..."

# Start services with Docker Compose
docker-compose up -d postgres redis

# Wait for services to be ready
echo "⏳ Waiting for services to start..."
sleep 10

# Start backend and frontend
docker-compose up -d backend frontend

# Start additional services
docker-compose up -d build-service ai-assistant

echo "✅ Development environment started!"
echo ""
echo "🌐 Frontend: http://localhost:3000"
echo "🚀 Backend API: http://localhost:3001"
echo "📊 API Docs: http://localhost:3001/api/docs"
echo "📈 Monitoring: http://localhost:3004 (Grafana)"
echo ""
echo "🔑 Default Login:"
echo "Email: admin@1clickngolive.com"
echo "Password: demo123"
EOF

    # Production startup script
    cat > start-prod.sh << EOF
#!/bin/bash

echo "🚀 Starting 1ClickNGolive Production Environment..."

# Build images
docker-compose build

# Start all services
docker-compose up -d

echo "✅ Production environment started!"
echo ""
echo "🌐 Application: https://1clickngolive.com"
echo "📊 Monitoring: https://monitoring.1clickngolive.com"
EOF

    # Stop script
    cat > stop.sh << EOF
#!/bin/bash

echo "🛑 Stopping 1ClickNGolive..."

docker-compose down

echo "✅ All services stopped!"
EOF

    # Make scripts executable
    chmod +x start-dev.sh start-prod.sh stop.sh
    
    print_success "Startup scripts created!"
}

# Create documentation
create_documentation() {
    print_status "Creating documentation..."
    
    cat > GETTING_STARTED.md << EOF
# 1ClickNGolive - Getting Started

## Quick Start

### Prerequisites
- Docker & Docker Compose
- Node.js 18+ (for local development)
- Git

### Installation

1. Clone the repository:
   \`\`\`bash
   git clone <repository-url>
   cd 1clickngolive-complete
   \`\`\`

2. Run the setup script:
   \`\`\`bash
   chmod +x setup.sh
   ./setup.sh
   \`\`\`

3. Update environment variables:
   - Edit \`backend/.env\` with your API keys
   - Edit \`frontend/.env\` with your configuration

4. Start the development environment:
   \`\`\`bash
   ./start-dev.sh
   \`\`\`

### Access the Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:3001
- **API Documentation**: http://localhost:3001/api/docs
- **Grafana Monitoring**: http://localhost:3004

### Default Login Credentials

- **Email**: admin@1clickngolive.com
- **Password**: demo123

## Architecture

### Services

1. **Frontend**: React-based user interface
2. **Backend**: NestJS API with PostgreSQL
3. **Build Service**: App/Website compilation service
4. **AI Assistant**: OpenAI-powered assistant
5. **Redis**: Caching and job queue
6. **PostgreSQL**: Primary database
7. **Monitoring**: Prometheus + Grafana

### Key Features

- ✅ **Website Builder**: Drag-and-drop website creation
- ✅ **App Builder**: Native mobile app generation
- ✅ **Template Marketplace**: Professional templates
- ✅ **AI Assistant**: SEO and design suggestions
- ✅ **Multi-tenant**: Organization-based isolation
- ✅ **Payment Integration**: Stripe and Razorpay
- ✅ **Build Pipeline**: Automated app/website compilation
- ✅ **Analytics**: Usage and performance tracking
- ✅ **Monitoring**: Real-time system monitoring

## Development

### Local Development

1. Install dependencies:
   \`\`\`bash
   cd backend && npm install
   cd ../frontend && npm install
   \`\`\`

2. Start services:
   \`\`\`bash
   ./start-dev.sh
   \`\`\`

3. Access development servers:
   - Frontend: http://localhost:3000
   - Backend: http://localhost:3001

### Building for Production

1. Build Docker images:
   \`\`\`bash
   docker-compose build
   \`\`\`

2. Start production environment:
   \`\`\`bash
   ./start-prod.sh
   \`\`\`

### Database Management

- **Migrations**: \`npm run migration:run\`
- **Seeds**: \`npm run seed\`
- **Backup**: \`docker exec postgres pg_dump -U postgres 1clickngolive > backup.sql\`

### Monitoring

- **Logs**: \`docker-compose logs -f [service]\`
- **Metrics**: http://localhost:9090 (Prometheus)
- **Dashboards**: http://localhost:3004 (Grafana)

## Deployment

### Docker Compose (Recommended for small deployments)

\`\`\`bash
./start-prod.sh
\`\`\`

### Kubernetes (Recommended for production)

\`\`\`bash
kubectl apply -f infrastructure/kubernetes/
\`\`\`

### Cloud Deployment

- **AWS**: Use EKS + RDS + ElastiCache
- **GCP**: Use GKE + Cloud SQL + Memorystore
- **Azure**: Use AKS + Azure Database + Redis Cache

## Configuration

### Environment Variables

See \`.env\` files in backend and frontend directories.

### Key Configurations

- **Database**: PostgreSQL connection settings
- **Redis**: Cache and queue settings
- **AWS**: S3 storage for files and builds
- **Stripe/Razorpay**: Payment processing
- **OpenAI**: AI assistant functionality
- **SMTP**: Email notifications

## Support

For support and questions:
- Email: support@1clickngolive.com
- Documentation: https://docs.1clickngolive.com
- Issues: Create GitHub issue

## License

Proprietary - 1ClickNGolive Platform
EOF

    print_success "Documentation created!"
}

# Main setup function
main() {
    echo "============================================"
    echo "  1ClickNGolive Complete Setup"
    echo "  Digital Ecosystem Platform"
    echo "============================================"
    echo ""
    
    check_prerequisites
    create_directories
    generate_env_files
    setup_database
    setup_backend
    setup_frontend
    setup_monitoring
    create_startup_script
    create_documentation
    
    echo ""
    echo "============================================"
    print_success "🎉 Setup completed successfully!"
    echo "============================================"
    echo ""
    print_status "Next steps:"
    echo "1. Update API keys in backend/.env and frontend/.env"
    echo "2. Run './start-dev.sh' to start development environment"
    echo "3. Access the application at http://localhost:3000"
    echo ""
    print_status "Default login credentials:"
    echo "Email: admin@1clickngolive.com"
    echo "Password: demo123"
    echo ""
    print_status "Documentation: See GETTING_STARTED.md for detailed instructions"
    echo ""
}

# Run main function
main "$@"