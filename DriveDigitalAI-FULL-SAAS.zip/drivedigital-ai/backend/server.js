const express=require("express");
const cors=require("cors");
const jwt=require("jsonwebtoken");
const app=express();
app.use(cors());
app.use(express.json());

app.get("/",(_,res)=>res.json({
  product:"DriveDigital AI",
  stage:"VC Demo",
  status:"LIVE"
}));

app.post("/auth/login",(req,res)=>{
  const {email,password}=req.body;
  if(email==="mdsalman@drivedigital.ai" && password==="HOORIAN"){
    return res.json({
      token:jwt.sign({role:"ADMIN"},"demo"),
      role:"SUPER_ADMIN"
    });
  }
  res.status(401).json({error:"Invalid login"});
});

app.get("/ai",(req,res)=>{
  res.json({
    engine:"Growth AI",
    outputs:["Ads","Funnels","Copy","ROI"]
  });
});

app.post("/billing",(req,res)=>{
  res.json({
    gateways:["Stripe","Razorpay","Paytm UPI"],
    mode:"DEMO"
  });
});

app.listen(4000,()=>console.log("Backend LIVE on 4000"));
