import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
void main()=>runApp(const App());
class App extends StatelessWidget{
const App({super.key});
@override Widget build(BuildContext c){
return const MaterialApp(
debugShowCheckedModeBanner:false,
home:WebView(
initialUrl:'https://YOUR-LIVE-URL',
javascriptMode:JavascriptMode.unrestricted,
));
}}
